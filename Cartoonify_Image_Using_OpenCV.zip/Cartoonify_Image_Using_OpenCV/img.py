#IMPORTING libraries
from tkinter import *
import sys
import os
import cv2
import easygui
import numpy as np
import matplotlib.pyplot as plt
import imageio
from tkinter import filedialog
from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox 

root=Tk()
root.geometry('600x550')
root.title('Cartoonify Your Image !')
root.configure(background='white')
lbl=Label(root, text="Cartoonify Image Using OpenCV", fg='#364156', font=("Helvetica", 20))
lbl.place(x=90, y=30)

def close1():
       plt.close()

#timer
fig = plt.figure()
timer = fig.canvas.new_timer(interval = 2500)
timer.add_callback(close1)

#Reading the image
def upload():
       ImagePath = easygui.fileopenbox()
       cartoonify(ImagePath)

def cartoonify(ImagePath):
        global img1
        img1 = cv2.imread(ImagePath)
        if img1 is None:
                print("Can not find any image. Choose appropriate file")
                sys.exit()
        img1 = cv2.cvtColor(img1, cv2.COLOR_BGR2RGB)
        root.after(1000,root.destroy())
        
        # Displaying all the images
        plt.imshow(img1) 
        plt.axis("off")
        plt.title("ORIGINAL IMAGE")
        timer.start()
        plt.show()

        # Converting the color space from RGB to Grayscale
        global img1g
        img1g = cv2.cvtColor(img1, cv2.COLOR_RGB2GRAY)
        plt.imshow(img1g, cmap='gray')
        plt.axis("off")
        plt.title("GRAYSCALE")
        plt.show()

        # Median Blurring
        global img1b
        img1b = cv2.medianBlur(img1g, 3)
        plt.imshow(img1b, cmap='gray')
        plt.axis("off")
        plt.title(" MEDIAN BLURRING")
        plt.show()

        # Creating edge mask
        global edges
        edges = cv2.adaptiveThreshold(img1b, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 3, 3)
        plt.imshow(edges, cmap='gray')
        plt.axis("off")
        plt.title("EDGE MASK")
        plt.show()

        # Removing noise
        global img1bb
        img1bb = cv2.bilateralFilter(img1b, 15, 75, 75) 
        plt.imshow(img1bb, cmap='gray')
        plt.axis("off")
        plt.title("BILATERAL BLURRING")
        plt.show()

        # Eroding and Dilating
        global kernel,img1e,img1d
        kernel = np.ones((1, 1), np.uint8)
        img1e = cv2.erode(img1bb, kernel, iterations=3)
        img1d = cv2.dilate(img1e, kernel, iterations=3)
        plt.imshow(img1d, cmap='gray')
        plt.axis("off")
        plt.title(" ERODING AND DILATING")
        plt.show()

        #COLOR QUANTIZATION

        # Color Quantization is implemented by using clustering alogrithms
        # Here we use exclusive clustering. K-MEANS technique is used.
        # Clustering - (K-MEANS)

        global imgf
        imgf = np.float32(img1).reshape(-1, 3)
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1.0)
        compactness, label, center = cv2.kmeans(imgf, 5, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
        center = np.uint8(center)
        final_img = center[label.flatten()]
        final_img = final_img.reshape(img1.shape)

        global final
        final = cv2.bitwise_and(final_img, final_img, mask=edges)
        plt.imshow(final, cmap='gray')
        plt.axis("off")
        plt.title("CARTOONIFIED IMAGE")
        plt.show()


#Select Image Button
upload1=Button(root,text="Select Image",command=upload,padx=15,pady=5)
upload1.configure(background='#364156', foreground='white', font=('times new roman', 16, 'bold'))
upload1.pack(side=TOP, pady=100)

exit_button =Button(root,text='Close',command=lambda:sys.exit(),activebackground="white")
exit_button.configure(background='#364156', foreground='white', font=('times new roman', 14, 'bold'))
exit_button.place(x=265, y=300)
       
#disabling controls
root.resizable(False, False)

#close icon
def on_closing():
    if messagebox.askyesnocancel("Quit", "Do you want to quit?"):
        sys.exit()
root.protocol("WM_DELETE_WINDOW", on_closing)

root.mainloop()