from img import *

root=Tk()
root.geometry('600x550')
root.title('Cartoonify Your Image !')
root.configure(background='white')
lbl=Label(root, text="Cartoonify Image Using OpenCV", fg='#364156', font=("Helvetica", 20))
lbl.place(x=90, y=30)

def original():
        global img1
        plt.imshow(img1) 
        plt.axis("off")
        plt.title("ORIGINAL IMAGE")
        timer.stop()
        plt.show()

def gray1():
        global img1g
        img1g = cv2.cvtColor(img1, cv2.COLOR_RGB2GRAY)
        plt.imshow(img1g, cmap='gray')
        plt.axis("off")
        plt.title("GRAYSCALE")
        timer.stop()
        plt.show()

def medblur():
        global img1b
        img1b = cv2.medianBlur(img1g, 3)
        plt.imshow(img1b, cmap='gray')
        plt.axis("off")
        plt.title(" MEDIAN BLURRING")
        timer.stop()
        plt.show()

def edgemask():
        global edges
        edges = cv2.adaptiveThreshold(img1b, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 3, 3)
        plt.imshow(edges, cmap='gray')
        plt.axis("off")
        plt.title("EDGE MASK")
        timer.stop()
        plt.show()

def bi_blur():
        global img1bb
        img1bb = cv2.bilateralFilter(img1b, 15, 75, 75) 
        plt.imshow(img1bb, cmap='gray')
        plt.axis("off")
        plt.title("BILATERAL BLURRING")
        timer.stop()
        plt.show()

def erodedilate():
        global kernel,img1e,img1d
        kernel = np.ones((1, 1), np.uint8)
        img1e = cv2.erode(img1bb, kernel, iterations=3)
        img1d = cv2.dilate(img1e, kernel, iterations=3)
        plt.imshow(img1d, cmap='gray')
        plt.axis("off")
        plt.title(" ERODING AND DILATING")
        timer.stop()
        plt.show()

def final1():
        global imgf,final
        imgf = np.float32(img1).reshape(-1, 3)
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1.0)
        compactness, label, center = cv2.kmeans(imgf, 5, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
        center = np.uint8(center)
        final_img = center[label.flatten()]
        final_img = final_img.reshape(img1.shape)
 
        final = cv2.bitwise_and(final_img, final_img, mask=edges)
        plt.imshow(final, cmap='gray')
        plt.axis("off")
        plt.title("CARTOONIFIED IMAGE")
        timer.stop()
        plt.show()
      
#Buttons
original =Button(root,text='Original Image',command=original,activebackground="white")
original.configure(background='#364156', foreground='white', font=('times new roman', 12, 'bold'))#
original.place(x=230, y=125)

gs = Button(root,text = "GrayScale",command=gray1)
gs.configure(background='#364156', foreground='white', font=('times new roman', 12, 'bold'))  
gs.place(x=28, y=200)

mb = Button(root,text = "Median Blurring",command=medblur)
mb.configure(background='#364156', foreground='white', font=('times new roman', 12, 'bold'))
mb.place(x=113, y=200)

em = Button(root,text = "Edge Mask",command=edgemask)
em.configure(background='#364156', foreground='white', font=('times new roman', 12, 'bold'))
em.place(x=239, y=200)

bb = Button(root,text = "Bilateral Blurring",command=bi_blur)
bb.configure(background='#364156', foreground='white', font=('times new roman', 12, 'bold'))  
bb.place(x=332, y=200)

ed = Button(root,text = "Erode & Dilate",command=erodedilate)
ed.configure(background='#364156', foreground='white', font=('times new roman', 12, 'bold'))  
ed.place(x=464, y=200)

fi = Button(root,text = "Final Image",command=final1)
fi.configure(background='#364156', foreground='white', font=('times new roman', 12, 'bold'))  
fi.place(x=240, y=275)#x=250, y=250

#exit button
exit_button =Button(root,text='Close',command=lambda: [root.destroy(),plt.close()])
exit_button.configure(background='#364156', foreground='white', font=('times new roman', 12, 'bold'))#
exit_button.place(x=258, y=375)

# #disabling controls
root.resizable(False, False)

#close icon
def on_closing():
    if messagebox.askyesnocancel("Quit", "Do you want to quit?"):
        sys.exit()
root.protocol("WM_DELETE_WINDOW", on_closing)

root.mainloop()